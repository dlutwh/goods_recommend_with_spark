#!/usr/bin/env python

import os
import sys
import datetime
from path import LIB_PATH, ENVIRONMENT, HIVE_CLIENT, PROJECTS_PATH
from path import *
from env_config import env_config
from kdt_util import safe_execute

# add lib and conf path to sys path
current_path = os.path.dirname(os.path.abspath(sys.argv[0]))
sys.path.append(current_path + "/../../conf")
sys.path.append(current_path + "/../../lib")

JOB_NAME = 'mars_goods_pool'
JOB_NAME_0 = '7d_land_shop'
JOB_NAME0 = 'mars_basic_filtered_goods'
# JOB_NAME1 = 'mars_team_kpi'
JOB_NAME2 = 'mars_goods_kpi'
JOB_NAME3 = 'mars_goods_kpi_max_min'
JOB_NAME4 = 'mars_goods_kpi_final'
JOB_NAME5 = 'mars_white_list_goods'
JOB_NAME6 = 'mars_new_created_goods'
JOB_NAME7 = 'mars_brand_goods'
JOB_NAME8 = 'mars_topic_goods'
JOB_NAME9 = 'mars_rank_goods'
JOB_NAME10 = 'mars_goods_pool'
JOB_HOME = "/".join([PROJECTS_PATH, JOB_NAME])
CONFIG_FILE = sys.argv[1]
CONFIG_FILE1 = CONFIG_FILE + '1'
CONFIG_FILE2 = CONFIG_FILE + '2'
CONFIG_FILE3 = CONFIG_FILE + '3'

END_DAY = sys.argv[2] if len(sys.argv) > 2 else ((datetime.date.today() - datetime.timedelta(1)).strftime('%Y%m%d'))
START_DAY = (datetime.datetime.strptime(END_DAY, "%Y%m%d") - datetime.timedelta(89)).strftime('%Y%m%d')
MID_DAY = (datetime.datetime.strptime(END_DAY, "%Y%m%d") - datetime.timedelta(7)).strftime('%Y%m%d')
YESTERDAY = (datetime.datetime.strptime(END_DAY, "%Y%m%d") - datetime.timedelta(1)).strftime('%Y%m%d')

# 0. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar START_DAY=%s --hivevar MID_DAY=%s " \
      "--hivevar END_DAY=%s --hivevar LIB_PATH=%s --hivevar hive_db=%s" % (
          HIVE_CLIENT, JOB_HOME, JOB_NAME_0, START_DAY, MID_DAY, END_DAY, LIB_PATH,
          env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 0. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar START_DAY=%s --hivevar MID_DAY=%s " \
      "--hivevar END_DAY=%s --hivevar LIB_PATH=%s --hivevar hive_db=%s" % (
          HIVE_CLIENT, JOB_HOME, JOB_NAME0, START_DAY, MID_DAY, END_DAY, LIB_PATH,
          env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 1. create the hive table and insert the data
# cmd = "%s/bin/hive -f %s/%s.hql --hivevar START_DAY=%s --hivevar MID_DAY=%s
# --hivevar END_DAY=%s --hivevar LIB_PATH=%s
# --hivevar hive_db=%s" % (HIVE_CLIENT,JOB_HOME,JOB_NAME1,START_DAY,MID_DAY,
# END_DAY,LIB_PATH,env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
# print >> sys.stderr,cmd
# safe_execute(cmd)


# 2. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar START_DAY=%s --hivevar MID_DAY=%s " \
      "--hivevar END_DAY=%s --hivevar LIB_PATH=%s --hivevar hive_db=%s" % (
          HIVE_CLIENT, JOB_HOME, JOB_NAME2, START_DAY, MID_DAY, END_DAY, LIB_PATH,
          env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 3. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME3, END_DAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 4. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME4, END_DAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 5. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME5, END_DAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 6. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME6, END_DAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 7. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME7, END_DAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 8. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME8, END_DAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 9. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar YESTERDAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME9, END_DAY, YESTERDAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)

# 10. create the hive table and insert the data
cmd = "%s/bin/hive -f %s/%s.hql --hivevar END_DAY=%s --hivevar hive_db=%s" % (
    HIVE_CLIENT, JOB_HOME, JOB_NAME10, END_DAY, env_config[ENVIRONMENT]["common_config"]["hive_db_name"])
print >> sys.stderr, cmd
safe_execute(cmd)
