#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

sys.path.append('../')

import jieba
import jieba.analyse

topK = 5

content = u"佳奥大号U型抱枕 男朋友抱枕 超大U抱枕 情人抱枕礼物"

content = content.encode("utf-8")

#tags = jieba.analyse.extract_tags(content, withWeight=True, topK=topK, allowPOS=('n'))

tags = jieba.analyse.textrank(content, topK=topK, withWeight=False, allowPOS=('ns', 'n', 'nr'))
words = list(jieba.posseg.cut(content))
print(",".join(tags))
#print tags
print words