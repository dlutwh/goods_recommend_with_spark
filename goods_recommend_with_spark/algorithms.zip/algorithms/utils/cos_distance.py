#!/usr/bin/env python
# -*- coding: utf-8 -*-
import jieba
import jieba.posseg
import datetime
import jieba.analyse

topK = 5


def cos_distance(string_a, string_b):
    # words_a_org = list(jieba.posseg.cut(string_a))  #取词和词性
    # words_b_org = list(jieba.posseg.cut(string_b))
    # words_a = [item.word for item in words_a_org if item.flag == "n"] #取名词
    # words_b = [item.word for item in words_b_org if item.flag == "n"]

    # print "string_a:", string_a
    # print "string_b:", string_b
    words_a = list(
            jieba.analyse.textrank(string_a, topK=topK, withWeight=False,
                                   allowPOS=('ns', 'n', 'nr')))  # 核心词提取,取名词,人名,地名
    words_b = list(jieba.analyse.textrank(string_b, topK=topK, withWeight=False, allowPOS=('ns', 'n', 'nr')))

    if 0 == len(words_a) or 0 == len(words_b):
        return 0

    all_words = list(set(words_a).union(set(words_b)))

    words_a_trans = []
    words_b_trans = []

    for item in all_words:
        if item in words_a:
            words_a_trans.append(1)
        else:
            words_a_trans.append(0)

        if item in words_b:
            words_b_trans.append(1)
        else:
            words_b_trans.append(0)

    return distance(words_a_trans, words_b_trans)


def distance(vector1, vector2):
    dot_product = 0.0
    norm_a = 0.0
    norm_b = 0.0
    for a, b in zip(vector1, vector2):
        dot_product += a * b
        norm_a += a ** 2
        norm_b += b ** 2
    if norm_a == 0.0 or norm_b == 0.0:
        return 0
    else:
        return dot_product / ((norm_a * norm_b) ** 0.5)


# class CosDistance():
#
#     def __init__(self, userdict_file=None):
#         if userdict_file:
#             jieba.load_userdict(userdict_file)
#
#     def cos_distance(self, string_a, string_b):
#         # words_a_org = list(jieba.posseg.cut(string_a))  #取词和词性
#         # words_b_org = list(jieba.posseg.cut(string_b))
#         # words_a = [item.word for item in words_a_org if item.flag == "n"] #取名词
#         # words_b = [item.word for item in words_b_org if item.flag == "n"]
#
#         # print "string_a:", string_a
#         # print "string_b:", string_b
#         words_a = list(
#                 jieba.analyse.textrank(string_a, topK=topK, withWeight=False,
#                                        allowPOS=('ns', 'n', 'nr')))  # 核心词提取,取名词,人名,地名
#         words_b = list(jieba.analyse.textrank(string_b, topK=topK, withWeight=False, allowPOS=('ns', 'n', 'nr')))
#
#         if 0 == len(words_a) or 0 == len(words_b):
#             return 0
#
#         all_words = list(set(words_a).union(set(words_b)))
#
#         words_a_trans = []
#         words_b_trans = []
#
#         for item in all_words:
#             if item in words_a:
#                 words_a_trans.append(1)
#             else:
#                 words_a_trans.append(0)
#
#             if item in words_b:
#                 words_b_trans.append(1)
#             else:
#                 words_b_trans.append(0)
#
#         return self.distance(words_a_trans, words_b_trans)
#
#     def distance(self, vector1, vector2):
#         dot_product = 0.0
#         norm_a = 0.0
#         norm_b = 0.0
#         for a, b in zip(vector1, vector2):
#             dot_product += a * b
#             norm_a += a ** 2
#             norm_b += b ** 2
#         if norm_a == 0.0 or norm_b == 0.0:
#             return 0
#         else:
#             return dot_product / ((norm_a * norm_b) ** 0.5)

if __name__ == "__main__":
    dis_object = CosDistance()
    string_A = "良品铺子】迷你烤香肠 290g*2 香辣味（非偏远地区包邮）"
    string_B = "良品铺子】新奥尔良风味小鸡腿158g"

    print dis_object.cos_distance(string_A, string_B)

