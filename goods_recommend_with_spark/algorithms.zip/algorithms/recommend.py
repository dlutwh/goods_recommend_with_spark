#!/usr/bin/env python
# -*- coding: utf-8 -*-
from utils.cos_distance import cos_distance

RESULT_NUM = 5


def recommend(origin, item_list):
    distance = {}
    for goods in item_list:
        dis = cos_distance(origin, goods['title'])
        idx = str(goods['id']) + '_' + goods['title']
        if dis != 0:
            distance[idx] = dis
    sort_dis = sorted(distance.iteritems(), key=lambda d: d[1], reverse=True)

    result_list = []
    result_num = min(RESULT_NUM, len(sort_dis))
    for i in range(result_num):
        result_list.append(sort_dis[i][0])
    result_list = list(set(result_list))

    return result_list


# class Recommend():
#     def __init__(self):
#         self.distance_object = CosDistance()
#
#     def recommend(self, origin, item_list):
#         print "###origin"
#         print origin
#         print "###origin"
#         for item in item_list:
#             print item
#         distance = {}
#         for goods_id, items in item_list.items():
#             dis = self.distance_object.cos_distance(origin, items)
#             if dis != 0:
#                 distance[goods_id] = dis
#         sort_dis = sorted(distance.iteritems(), key=lambda d: d[1], reverse=True)
#
#         result_list = []
#         for i in range(RESULT_NUM):
#             result_list.append(sort_dis[i][0])
#         result_list = list(set(result_list))
#
#         # final_result_list = []
#
#         return result_list


if __name__ == "__main__":
    origin_str = "良品铺子】迷你烤香肠 290g*2 香辣味（非偏远地区包邮)"
    item_lis = {249672126: u'【良品铺子】风味猪肉脯自然片100g 香辣味/芝麻味  每个ID限购3份', \
                248546864: u'20:30粉丝秒杀专场【良品铺子】黄桃果干 98g  每个ID限购1份', \
                248157890: u'【良品铺子】海带丝 218g*2 香辣味/泡椒味 ', 248141540: u'【3周年庆抽奖】花千骨手办', \
                249271814: u'3折限量 麻辣豆干 188g   每个ID限购2份', 247912328: u'【良品铺子】腰果 180g   炭烧味/盐焗味/香辣味  每个ID限购5份', \
                249899468: u'20:30粉丝福利0.1元秒杀【良品铺子】柠檬片 70g  每个ID限购1份', 248374274: u' 领劵满100减30【良品铺子】山楂夹心枣 120g ', \
                248302830: u'【良品铺子】风味猪肉脯自然片100g 香辣味/芝麻味  每个ID限购3份', 248473744: u'满100减30【良品铺子】肉松饼整箱  2100g ', \
                248899368: u'【良品铺子】腰果 180g   炭烧味 每个ID限购5份 （全场满68元包邮）',
                248433010: u'【良品铺子】吃货专属兑换大礼包 1176g  8款零食组合 戳图抱走☟☟', \
                248010580: u'【良品铺子】手撕面包 330g  每个ID限购2份', 249399118: u'【良品铺子】脆笋 188g 泡椒味/香辣味  每个ID限购5份', \
                250204438: u'【良品铺子】香酥小黄鱼 118g  每个ID限购3份', 249399172: u'5折限量【良品铺子】手撕面包 330g  每个ID限购2份', \
                249398536: u'3折限量 桂花加应子120g  每个ID限购3份', 248746644: u' 25人成团【限量500份】炭烧腰果 180g   更多秒杀进入首页，3元抢，3-5折秒', \
                248785914: u'满100减30【良品铺子】紫薯花生 120g ', 248172574: u'顺丰包邮【良品铺子】美国柠檬 12个/2.4斤以上 顺丰包邮  团购商品不参与满送及优惠劵活动'}

    recommend_object = Recommend()
    results = recommend_object.recommend(origin_str, item_lis)

    for result in results:
        print result
